package com.zx.onlineshop.service.Impl;

import com.zx.onlineshop.dao.UserMapper;
import com.zx.onlineshop.model.User;
import com.zx.onlineshop.model.UserExample;
import com.zx.onlineshop.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public User login(User user) {
        UserExample example = new UserExample();
        example.or().andUsernameEqualTo(user.getUsername()).andPasswordEqualTo(user.getPassword());
        List<User> userList = userMapper.selectByExample(example);
        User login = null;
        if(userList.size()!=0){
            login = userList.get(0);
        }

        return login;
    }
}
