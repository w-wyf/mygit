package com.zx.onlineshop.service;

import com.zx.onlineshop.model.Good;

import java.util.List;

public interface GoodService {

    boolean addGood(Good good);

    boolean updateGood(Good good);

    boolean deleteGood(int id);

    List<Good> searchGood();

    Good findGood(int id);

}
