package com.zx.onlineshop.controller;

import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlPartitioningDef;
import com.zx.onlineshop.model.User;
import com.zx.onlineshop.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/login")
    public ModelAndView login(HttpServletRequest request){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        User login = userService.login(user);
        if(login!=null){
            request.getSession().setAttribute("realname",login.getRealname());
            return new ModelAndView("redirect:/index.jsp");
        }else{
            return new ModelAndView("failure","message","用户名或密码错误");
        }

    }

    @RequestMapping("/logout")
    public ModelAndView logout(HttpServletRequest request){
        request.getSession().invalidate();
        return new ModelAndView("redirect:/login.jsp");
    }

}
