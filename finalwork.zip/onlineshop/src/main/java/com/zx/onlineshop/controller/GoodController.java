package com.zx.onlineshop.controller;

import com.zx.onlineshop.model.Good;
import com.zx.onlineshop.service.GoodService;
import com.zx.onlineshop.service.TypeService;
import com.zx.onlineshop.vo.GoodVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/good")
public class GoodController {

    @Autowired
    GoodService goodService;
    @Autowired
    TypeService typeService;

    @GetMapping("/add")
    public ModelAndView addGood(){
        Map<Integer, String> map = typeService.getMap();
        ModelAndView mav = new ModelAndView();
        mav.setViewName("addGood");
        mav.addObject("map",map);
        return mav;
    }

    @PostMapping("/doadd")
    public ModelAndView doAdd(HttpServletRequest request){
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int typeId = Integer.parseInt(request.getParameter("typeId"));
        String price = request.getParameter("price");
        int currentNum = Integer.parseInt(request.getParameter("currentNum"));

        Good good = new Good(id,name,typeId,price,currentNum);
        if(goodService.addGood(good)){
            return new ModelAndView("success","message","add good success!");
        }else{
            return new ModelAndView("failure","message","add good failed!");
        }
    }

    @PostMapping("/doupdate")
    public ModelAndView doUpdate(HttpServletRequest request){

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int typeId = Integer.parseInt(request.getParameter("typeId"));
        String price = request.getParameter("price");
        int currentNum = Integer.parseInt(request.getParameter("currentNum"));

        Good good = new Good(id,name,typeId,price,currentNum);
        if(goodService.updateGood(good)){
            return new ModelAndView("success","message","update good success!");
        }else{
            return new ModelAndView("failure","message","update good failed!");
        }
    }

    @GetMapping("/update")
    public ModelAndView updateGood(HttpServletRequest request){

        int id = Integer.parseInt(request.getParameter("id"));
        Good good = goodService.findGood(id);
        Map<Integer,String> map = typeService.getMap();
        ModelAndView mav = new ModelAndView();
        mav.setViewName("update");
        mav.addObject("good",good);
        mav.addObject("map",map);

        return mav;
    }

    @GetMapping("/delete")
    public ModelAndView deleteGood(@RequestParam int id){
        if(goodService.deleteGood(id)){
            return new ModelAndView("/success.jsp","message","delete good success!");
        }else{
            return new ModelAndView("/failure.jsp","message","delete good failed!");
        }
    }

    @RequestMapping("/all")
    public ModelAndView searchGood(){
        List<GoodVo> goodVoList = new ArrayList<>();
        List<Good> goodList = goodService.searchGood();
        Map<Integer, String> map = typeService.getMap();
        for(Good good: goodList){
            GoodVo goodVo = new GoodVo();
            goodVo.setId(good.getId());
            goodVo.setName(good.getName());
            goodVo.setType(map.get(good.getTypeId()));
            goodVo.setPrice(good.getPrice());
            goodVo.setCurrentNum(good.getCurrentNum());
            goodVoList.add(goodVo);
        }
        return new ModelAndView("good","good",goodVoList);
    }

}
