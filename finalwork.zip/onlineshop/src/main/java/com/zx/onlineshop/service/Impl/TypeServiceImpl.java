package com.zx.onlineshop.service.Impl;

import com.zx.onlineshop.dao.TypeMapper;
import com.zx.onlineshop.model.Type;
import com.zx.onlineshop.model.TypeExample;
import com.zx.onlineshop.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("typeService")
public class TypeServiceImpl implements TypeService {

    @Autowired
    TypeMapper typeMapper;

    @Override
    public boolean addType(Type type) {

        typeMapper.insert(type);

        return true;
    }

    @Override
    public boolean deleteType(int id) {

        typeMapper.deleteByPrimaryKey(id);

        return true;
    }

    @Override
    public boolean updateType(Type type) {

        typeMapper.updateByPrimaryKeySelective(type);

        return true;
    }

    @Override
    public List<Type> searchType() {
        return typeMapper.selectByExample(new TypeExample());
    }

    @Override
    public int getTypeId(String name) {

        TypeExample example = new TypeExample();
        example.or().andNameEqualTo(name);
        Type type = typeMapper.selectByExample(example).get(0);

        return type.getId();
    }

    @Override
    public Map<Integer, String> getMap() {
        Map<Integer,String> map = new HashMap<>();
        List<Type> typeList = typeMapper.selectByExample(new TypeExample());
        for(Type type : typeList){
            map.put(type.getId(),type.getName());
        }
        return map;
    }
}
