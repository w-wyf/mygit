package com.zx.onlineshop.service;

import com.zx.onlineshop.model.Type;

import java.util.List;
import java.util.Map;

public interface TypeService {

    boolean addType(Type type);

    boolean deleteType(int id);

    boolean updateType(Type type);

    List<Type> searchType();

    int getTypeId(String name);

    Map<Integer,String> getMap();
}
