package com.zx.onlineshop.service;

import com.zx.onlineshop.model.User;

public interface UserService {

    User login(User user);

}
