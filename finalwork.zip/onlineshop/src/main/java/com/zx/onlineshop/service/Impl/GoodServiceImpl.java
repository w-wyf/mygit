package com.zx.onlineshop.service.Impl;

import com.zx.onlineshop.dao.GoodMapper;
import com.zx.onlineshop.model.Good;
import com.zx.onlineshop.model.GoodExample;
import com.zx.onlineshop.service.GoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("goodService")
public class GoodServiceImpl implements GoodService {

    @Autowired
    GoodMapper goodMapper;

    @Override
    public boolean addGood(Good good) {

        goodMapper.insert(good);

        return true;
    }

    @Override
    public boolean updateGood(Good good) {

        goodMapper.updateByPrimaryKeySelective(good);

        return true;
    }

    @Override
    public boolean deleteGood(int id) {

        goodMapper.deleteByPrimaryKey(id);

        return true;
    }

    @Override
    public List<Good> searchGood() {

        List<Good> goods = goodMapper.selectByExample(new GoodExample());

        return goods;
    }

    @Override
    public Good findGood(int id) {

        return goodMapper.selectByPrimaryKey(id);
    }
}
