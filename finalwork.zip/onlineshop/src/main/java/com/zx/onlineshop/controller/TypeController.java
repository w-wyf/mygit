package com.zx.onlineshop.controller;

import com.zx.onlineshop.model.Type;
import com.zx.onlineshop.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

@Controller
@RequestMapping("/type")
public class TypeController {

    @Autowired
    TypeService typeService;

    @PostMapping("/add")
    public ModelAndView addType(HttpServletRequest request) throws UnsupportedEncodingException {
        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("name");
        Type type = new Type();
        type.setName(name);
        if(typeService.addType(type)){
            return new ModelAndView("success","message","add type success!");
        }else{
            return new ModelAndView("failure","message","add type failed!");
        }
    }
    @PostMapping("/update")
    public ModelAndView UpdateType(HttpServletRequest request) throws UnsupportedEncodingException {
        request.setCharacterEncoding("UTF-8");
        Type type = new Type();
        type.setId(Integer.parseInt(request.getParameter("id")));
        type.setName(request.getParameter("name"));
        if(typeService.updateType(type)){
            return new ModelAndView("success","message","update type success!");
        }else{
            return new ModelAndView("failure","message","update type failed!");
        }
    }


    @GetMapping("/delete")
    public ModelAndView deleteGood(@RequestParam int id){
        if(typeService.deleteType(id)){
            return new ModelAndView("success","message","delete type success!");
        }else{
            return new ModelAndView("failure","message","delete type failed!");
        }
    }

    @GetMapping("/all")
    public ModelAndView searchGood(){
        return new ModelAndView("type","type",typeService.searchType());
    }

}
